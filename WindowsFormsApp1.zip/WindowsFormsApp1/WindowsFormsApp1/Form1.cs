﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            List<string> input = new List<string>();
            input.Add(tb_kata1.Text);
            input.Add(tb_kata2.Text);
            input.Add(tb_kata3.Text);
            input.Add(tb_kata4.Text);
            input.Add(tb_kata5.Text);
            int count = 0;
            for (int i = 0; i <= 4; i++)
            {
                if (input[i].Length != 5)
                {
                    count++;
                }
            }
            bool yn = false;
            foreach (string x in input)
            {
                foreach (char y in x)
                {
                    if (char.IsDigit(y))
                    {
                        yn = true;
                    }
                }
            }
            List<string> word = new List<string>();
            word.Add(input[0]);
            for (int i = 1; i <= 4; i++)
            {
                int countsama = 0;
                for (int j = 0; j < word.Count; j++)
                {
                    if (word[j] == input[i])
                    {
                        countsama++;
                    }
                }
                if (countsama == 0)
                {
                    word.Add(input[i]);
                }
            }
            if (word.Count < 5 || count > 0 || yn == true)
            {
                MessageBox.Show("ERROR!");
            }
            else
            {
                play tebak = new play();
                tebak.kata = word;
                tebak.ShowDialog();
            }
        }
    }
}

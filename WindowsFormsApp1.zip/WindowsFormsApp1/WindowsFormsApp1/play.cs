﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class play : Form
    {
        public List<string> kata;
        string katatebak;
        public play()
        {
            InitializeComponent();
        }
        private void play_Load(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int angkarnd = rnd.Next(kata.Count);
            katatebak = kata[angkarnd];
        }
        public void Guess(char x)
        {
            for (int i = 0; i < 5; i++)
            {
                if (x == katatebak[i])
                {
                    if (i == 0)
                    {
                        lbl_kata1.Text = Convert.ToString(x);
                    }
                    if (i == 1)
                    {
                        lbl_kata2.Text = Convert.ToString(x);
                    }
                    if (i == 2)
                    {
                        lbl_kata3.Text = Convert.ToString(x);
                    }
                    if (i == 3)
                    {
                        lbl_kata4.Text = Convert.ToString(x);
                    }
                    if (i == 4)
                    {
                        lbl_kata5.Text = Convert.ToString(x);
                    }
                }
            }
            Menang();
        }
        private void Menang()
        {
            string rangkum = lbl_kata1.Text + lbl_kata2.Text + lbl_kata3.Text + lbl_kata4.Text + lbl_kata5.Text;
            if (rangkum == katatebak)
            {
                MessageBox.Show("HORE");
            }
        }
        private void bt_Q_Click(object sender, EventArgs e)
        {
            Guess('q');
        }
        private void bt_W_Click(object sender, EventArgs e)
        {
            Guess('w');
        }
        private void bt_E_Click(object sender, EventArgs e)
        {
            Guess('e');
        }
        private void bt_R_Click(object sender, EventArgs e)
        {
            Guess('r');
        }
        private void bt_T_Click(object sender, EventArgs e)
        {
            Guess('t');
        }
        private void bt_Y_Click(object sender, EventArgs e)
        {
            Guess('y');
        }
        private void bt_U_Click(object sender, EventArgs e)
        {
            Guess('u');
        }
        private void bt_I_Click(object sender, EventArgs e)
        {
            Guess('i');
        }
        private void bt_O_Click(object sender, EventArgs e)
        {
            Guess('o');
        }
        private void bt_P_Click(object sender, EventArgs e)
        {
            Guess('p');
        }
        private void bt_A_Click(object sender, EventArgs e)
        {
            Guess('a');
        }
        private void bt_S_Click(object sender, EventArgs e)
        {
            Guess('s');
        }
        private void bt_D_Click(object sender, EventArgs e)
        {
            Guess('d');
        }
        private void bt_F_Click(object sender, EventArgs e)
        {
            Guess('f');
        }
        private void bt_G_Click(object sender, EventArgs e)
        {
            Guess('g');
        }
        private void bt_H_Click(object sender, EventArgs e)
        {
            Guess('h');
        }

        private void bt_J_Click(object sender, EventArgs e)
        {
            Guess('j');
        }

        private void bt_K_Click(object sender, EventArgs e)
        {
            Guess('k');
        }

        private void bt_L_Click(object sender, EventArgs e)
        {
            Guess('l');
        }
        private void bt_Z_Click(object sender, EventArgs e)
        {
            Guess('z');
        }
        private void bt_X_Click(object sender, EventArgs e)
        {
            Guess('x');
        }
        private void bt_C_Click(object sender, EventArgs e)
        {
            Guess('c');
        }
        private void bt_V_Click(object sender, EventArgs e)
        {
            Guess('v');
        }
        private void bt_B_Click(object sender, EventArgs e)
        {
            Guess('b');
        }
        private void bt_N_Click(object sender, EventArgs e)
        {
            Guess('n');
        }
        private void bt_M_Click(object sender, EventArgs e)
        {
            Guess('m');
        }
    }
}
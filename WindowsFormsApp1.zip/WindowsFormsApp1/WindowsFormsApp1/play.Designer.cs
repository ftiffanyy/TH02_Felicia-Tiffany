﻿namespace WindowsFormsApp1
{
    partial class play
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_Q = new System.Windows.Forms.Button();
            this.bt_E = new System.Windows.Forms.Button();
            this.bt_W = new System.Windows.Forms.Button();
            this.bt_Y = new System.Windows.Forms.Button();
            this.bt_R = new System.Windows.Forms.Button();
            this.bt_T = new System.Windows.Forms.Button();
            this.bt_U = new System.Windows.Forms.Button();
            this.bt_I = new System.Windows.Forms.Button();
            this.bt_O = new System.Windows.Forms.Button();
            this.bt_P = new System.Windows.Forms.Button();
            this.bt_L = new System.Windows.Forms.Button();
            this.bt_K = new System.Windows.Forms.Button();
            this.bt_J = new System.Windows.Forms.Button();
            this.bt_G = new System.Windows.Forms.Button();
            this.bt_F = new System.Windows.Forms.Button();
            this.bt_H = new System.Windows.Forms.Button();
            this.bt_S = new System.Windows.Forms.Button();
            this.bt_D = new System.Windows.Forms.Button();
            this.bt_A = new System.Windows.Forms.Button();
            this.bt_M = new System.Windows.Forms.Button();
            this.bt_B = new System.Windows.Forms.Button();
            this.bt_V = new System.Windows.Forms.Button();
            this.bt_N = new System.Windows.Forms.Button();
            this.bt_X = new System.Windows.Forms.Button();
            this.bt_C = new System.Windows.Forms.Button();
            this.bt_Z = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_kata1 = new System.Windows.Forms.Label();
            this.lbl_kata2 = new System.Windows.Forms.Label();
            this.lbl_kata3 = new System.Windows.Forms.Label();
            this.lbl_kata4 = new System.Windows.Forms.Label();
            this.lbl_kata5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_Q
            // 
            this.bt_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Q.Location = new System.Drawing.Point(59, 106);
            this.bt_Q.Name = "bt_Q";
            this.bt_Q.Size = new System.Drawing.Size(45, 45);
            this.bt_Q.TabIndex = 0;
            this.bt_Q.Text = "Q";
            this.bt_Q.UseVisualStyleBackColor = true;
            this.bt_Q.Click += new System.EventHandler(this.bt_Q_Click);
            // 
            // bt_E
            // 
            this.bt_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_E.Location = new System.Drawing.Point(151, 106);
            this.bt_E.Name = "bt_E";
            this.bt_E.Size = new System.Drawing.Size(45, 45);
            this.bt_E.TabIndex = 1;
            this.bt_E.Text = "E";
            this.bt_E.UseVisualStyleBackColor = true;
            this.bt_E.Click += new System.EventHandler(this.bt_E_Click);
            // 
            // bt_W
            // 
            this.bt_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_W.Location = new System.Drawing.Point(105, 106);
            this.bt_W.Name = "bt_W";
            this.bt_W.Size = new System.Drawing.Size(45, 45);
            this.bt_W.TabIndex = 2;
            this.bt_W.Text = "W";
            this.bt_W.UseVisualStyleBackColor = true;
            this.bt_W.Click += new System.EventHandler(this.bt_W_Click);
            // 
            // bt_Y
            // 
            this.bt_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Y.Location = new System.Drawing.Point(289, 106);
            this.bt_Y.Name = "bt_Y";
            this.bt_Y.Size = new System.Drawing.Size(45, 45);
            this.bt_Y.TabIndex = 3;
            this.bt_Y.Text = "Y";
            this.bt_Y.UseVisualStyleBackColor = true;
            this.bt_Y.Click += new System.EventHandler(this.bt_Y_Click);
            // 
            // bt_R
            // 
            this.bt_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_R.Location = new System.Drawing.Point(197, 106);
            this.bt_R.Name = "bt_R";
            this.bt_R.Size = new System.Drawing.Size(45, 45);
            this.bt_R.TabIndex = 4;
            this.bt_R.Text = "R";
            this.bt_R.UseVisualStyleBackColor = true;
            this.bt_R.Click += new System.EventHandler(this.bt_R_Click);
            // 
            // bt_T
            // 
            this.bt_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_T.Location = new System.Drawing.Point(243, 106);
            this.bt_T.Name = "bt_T";
            this.bt_T.Size = new System.Drawing.Size(45, 45);
            this.bt_T.TabIndex = 5;
            this.bt_T.Text = "T";
            this.bt_T.UseVisualStyleBackColor = true;
            this.bt_T.Click += new System.EventHandler(this.bt_T_Click);
            // 
            // bt_U
            // 
            this.bt_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_U.Location = new System.Drawing.Point(335, 106);
            this.bt_U.Name = "bt_U";
            this.bt_U.Size = new System.Drawing.Size(45, 45);
            this.bt_U.TabIndex = 6;
            this.bt_U.Text = "U";
            this.bt_U.UseVisualStyleBackColor = true;
            this.bt_U.Click += new System.EventHandler(this.bt_U_Click);
            // 
            // bt_I
            // 
            this.bt_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_I.Location = new System.Drawing.Point(381, 106);
            this.bt_I.Name = "bt_I";
            this.bt_I.Size = new System.Drawing.Size(45, 45);
            this.bt_I.TabIndex = 7;
            this.bt_I.Text = "I";
            this.bt_I.UseVisualStyleBackColor = true;
            this.bt_I.Click += new System.EventHandler(this.bt_I_Click);
            // 
            // bt_O
            // 
            this.bt_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_O.Location = new System.Drawing.Point(427, 106);
            this.bt_O.Name = "bt_O";
            this.bt_O.Size = new System.Drawing.Size(45, 45);
            this.bt_O.TabIndex = 8;
            this.bt_O.Text = "O";
            this.bt_O.UseVisualStyleBackColor = true;
            this.bt_O.Click += new System.EventHandler(this.bt_O_Click);
            // 
            // bt_P
            // 
            this.bt_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_P.Location = new System.Drawing.Point(473, 106);
            this.bt_P.Name = "bt_P";
            this.bt_P.Size = new System.Drawing.Size(45, 45);
            this.bt_P.TabIndex = 9;
            this.bt_P.Text = "P";
            this.bt_P.UseVisualStyleBackColor = true;
            this.bt_P.Click += new System.EventHandler(this.bt_P_Click);
            // 
            // bt_L
            // 
            this.bt_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_L.Location = new System.Drawing.Point(454, 152);
            this.bt_L.Name = "bt_L";
            this.bt_L.Size = new System.Drawing.Size(45, 45);
            this.bt_L.TabIndex = 19;
            this.bt_L.Text = "L";
            this.bt_L.UseVisualStyleBackColor = true;
            this.bt_L.Click += new System.EventHandler(this.bt_L_Click);
            // 
            // bt_K
            // 
            this.bt_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_K.Location = new System.Drawing.Point(408, 152);
            this.bt_K.Name = "bt_K";
            this.bt_K.Size = new System.Drawing.Size(45, 45);
            this.bt_K.TabIndex = 18;
            this.bt_K.Text = "K";
            this.bt_K.UseVisualStyleBackColor = true;
            this.bt_K.Click += new System.EventHandler(this.bt_K_Click);
            // 
            // bt_J
            // 
            this.bt_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_J.Location = new System.Drawing.Point(362, 152);
            this.bt_J.Name = "bt_J";
            this.bt_J.Size = new System.Drawing.Size(45, 45);
            this.bt_J.TabIndex = 17;
            this.bt_J.Text = "J";
            this.bt_J.UseVisualStyleBackColor = true;
            this.bt_J.Click += new System.EventHandler(this.bt_J_Click);
            // 
            // bt_G
            // 
            this.bt_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_G.Location = new System.Drawing.Point(270, 152);
            this.bt_G.Name = "bt_G";
            this.bt_G.Size = new System.Drawing.Size(45, 45);
            this.bt_G.TabIndex = 16;
            this.bt_G.Text = "G";
            this.bt_G.UseVisualStyleBackColor = true;
            this.bt_G.Click += new System.EventHandler(this.bt_G_Click);
            // 
            // bt_F
            // 
            this.bt_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_F.Location = new System.Drawing.Point(224, 152);
            this.bt_F.Name = "bt_F";
            this.bt_F.Size = new System.Drawing.Size(45, 45);
            this.bt_F.TabIndex = 15;
            this.bt_F.Text = "F";
            this.bt_F.UseVisualStyleBackColor = true;
            this.bt_F.Click += new System.EventHandler(this.bt_F_Click);
            // 
            // bt_H
            // 
            this.bt_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_H.Location = new System.Drawing.Point(316, 152);
            this.bt_H.Name = "bt_H";
            this.bt_H.Size = new System.Drawing.Size(45, 45);
            this.bt_H.TabIndex = 14;
            this.bt_H.Text = "H";
            this.bt_H.UseVisualStyleBackColor = true;
            this.bt_H.Click += new System.EventHandler(this.bt_H_Click);
            // 
            // bt_S
            // 
            this.bt_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_S.Location = new System.Drawing.Point(132, 152);
            this.bt_S.Name = "bt_S";
            this.bt_S.Size = new System.Drawing.Size(45, 45);
            this.bt_S.TabIndex = 13;
            this.bt_S.Text = "S";
            this.bt_S.UseVisualStyleBackColor = true;
            this.bt_S.Click += new System.EventHandler(this.bt_S_Click);
            // 
            // bt_D
            // 
            this.bt_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_D.Location = new System.Drawing.Point(178, 152);
            this.bt_D.Name = "bt_D";
            this.bt_D.Size = new System.Drawing.Size(45, 45);
            this.bt_D.TabIndex = 12;
            this.bt_D.Text = "D";
            this.bt_D.UseVisualStyleBackColor = true;
            this.bt_D.Click += new System.EventHandler(this.bt_D_Click);
            // 
            // bt_A
            // 
            this.bt_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_A.Location = new System.Drawing.Point(86, 152);
            this.bt_A.Name = "bt_A";
            this.bt_A.Size = new System.Drawing.Size(45, 45);
            this.bt_A.TabIndex = 11;
            this.bt_A.Text = "A";
            this.bt_A.UseVisualStyleBackColor = true;
            this.bt_A.Click += new System.EventHandler(this.bt_A_Click);
            // 
            // bt_M
            // 
            this.bt_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_M.Location = new System.Drawing.Point(408, 198);
            this.bt_M.Name = "bt_M";
            this.bt_M.Size = new System.Drawing.Size(45, 45);
            this.bt_M.TabIndex = 27;
            this.bt_M.Text = "M";
            this.bt_M.UseVisualStyleBackColor = true;
            this.bt_M.Click += new System.EventHandler(this.bt_M_Click);
            // 
            // bt_B
            // 
            this.bt_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_B.Location = new System.Drawing.Point(316, 198);
            this.bt_B.Name = "bt_B";
            this.bt_B.Size = new System.Drawing.Size(45, 45);
            this.bt_B.TabIndex = 26;
            this.bt_B.Text = "B";
            this.bt_B.UseVisualStyleBackColor = true;
            this.bt_B.Click += new System.EventHandler(this.bt_B_Click);
            // 
            // bt_V
            // 
            this.bt_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_V.Location = new System.Drawing.Point(270, 198);
            this.bt_V.Name = "bt_V";
            this.bt_V.Size = new System.Drawing.Size(45, 45);
            this.bt_V.TabIndex = 25;
            this.bt_V.Text = "V";
            this.bt_V.UseVisualStyleBackColor = true;
            this.bt_V.Click += new System.EventHandler(this.bt_V_Click);
            // 
            // bt_N
            // 
            this.bt_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_N.Location = new System.Drawing.Point(362, 198);
            this.bt_N.Name = "bt_N";
            this.bt_N.Size = new System.Drawing.Size(45, 45);
            this.bt_N.TabIndex = 24;
            this.bt_N.Text = "N";
            this.bt_N.UseVisualStyleBackColor = true;
            this.bt_N.Click += new System.EventHandler(this.bt_N_Click);
            // 
            // bt_X
            // 
            this.bt_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_X.Location = new System.Drawing.Point(178, 198);
            this.bt_X.Name = "bt_X";
            this.bt_X.Size = new System.Drawing.Size(45, 45);
            this.bt_X.TabIndex = 23;
            this.bt_X.Text = "X";
            this.bt_X.UseVisualStyleBackColor = true;
            this.bt_X.Click += new System.EventHandler(this.bt_X_Click);
            // 
            // bt_C
            // 
            this.bt_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_C.Location = new System.Drawing.Point(224, 198);
            this.bt_C.Name = "bt_C";
            this.bt_C.Size = new System.Drawing.Size(45, 45);
            this.bt_C.TabIndex = 22;
            this.bt_C.Text = "C";
            this.bt_C.UseVisualStyleBackColor = true;
            this.bt_C.Click += new System.EventHandler(this.bt_C_Click);
            // 
            // bt_Z
            // 
            this.bt_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Z.Location = new System.Drawing.Point(132, 198);
            this.bt_Z.Name = "bt_Z";
            this.bt_Z.Size = new System.Drawing.Size(45, 45);
            this.bt_Z.TabIndex = 21;
            this.bt_Z.Text = "Z";
            this.bt_Z.UseVisualStyleBackColor = true;
            this.bt_Z.Click += new System.EventHandler(this.bt_Z_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(153, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 73);
            this.label1.TabIndex = 28;
            this.label1.Text = "_ _ _ _ _";
            // 
            // lbl_kata1
            // 
            this.lbl_kata1.AutoSize = true;
            this.lbl_kata1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kata1.Location = new System.Drawing.Point(153, 1);
            this.lbl_kata1.Name = "lbl_kata1";
            this.lbl_kata1.Size = new System.Drawing.Size(0, 73);
            this.lbl_kata1.TabIndex = 29;
            // 
            // lbl_kata2
            // 
            this.lbl_kata2.AutoSize = true;
            this.lbl_kata2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kata2.Location = new System.Drawing.Point(205, 1);
            this.lbl_kata2.Name = "lbl_kata2";
            this.lbl_kata2.Size = new System.Drawing.Size(0, 73);
            this.lbl_kata2.TabIndex = 30;
            // 
            // lbl_kata3
            // 
            this.lbl_kata3.AutoSize = true;
            this.lbl_kata3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kata3.Location = new System.Drawing.Point(256, 1);
            this.lbl_kata3.Name = "lbl_kata3";
            this.lbl_kata3.Size = new System.Drawing.Size(0, 73);
            this.lbl_kata3.TabIndex = 31;
            // 
            // lbl_kata4
            // 
            this.lbl_kata4.AutoSize = true;
            this.lbl_kata4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kata4.Location = new System.Drawing.Point(308, 1);
            this.lbl_kata4.Name = "lbl_kata4";
            this.lbl_kata4.Size = new System.Drawing.Size(0, 73);
            this.lbl_kata4.TabIndex = 32;
            // 
            // lbl_kata5
            // 
            this.lbl_kata5.AutoSize = true;
            this.lbl_kata5.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kata5.Location = new System.Drawing.Point(361, 1);
            this.lbl_kata5.Name = "lbl_kata5";
            this.lbl_kata5.Size = new System.Drawing.Size(0, 73);
            this.lbl_kata5.TabIndex = 33;
            // 
            // play
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 279);
            this.Controls.Add(this.lbl_kata5);
            this.Controls.Add(this.lbl_kata4);
            this.Controls.Add(this.lbl_kata3);
            this.Controls.Add(this.lbl_kata2);
            this.Controls.Add(this.lbl_kata1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_M);
            this.Controls.Add(this.bt_B);
            this.Controls.Add(this.bt_V);
            this.Controls.Add(this.bt_N);
            this.Controls.Add(this.bt_X);
            this.Controls.Add(this.bt_C);
            this.Controls.Add(this.bt_Z);
            this.Controls.Add(this.bt_L);
            this.Controls.Add(this.bt_K);
            this.Controls.Add(this.bt_J);
            this.Controls.Add(this.bt_G);
            this.Controls.Add(this.bt_F);
            this.Controls.Add(this.bt_H);
            this.Controls.Add(this.bt_S);
            this.Controls.Add(this.bt_D);
            this.Controls.Add(this.bt_A);
            this.Controls.Add(this.bt_P);
            this.Controls.Add(this.bt_O);
            this.Controls.Add(this.bt_I);
            this.Controls.Add(this.bt_U);
            this.Controls.Add(this.bt_T);
            this.Controls.Add(this.bt_R);
            this.Controls.Add(this.bt_Y);
            this.Controls.Add(this.bt_W);
            this.Controls.Add(this.bt_E);
            this.Controls.Add(this.bt_Q);
            this.Name = "play";
            this.Text = "play";
            this.Load += new System.EventHandler(this.play_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_Q;
        private System.Windows.Forms.Button bt_E;
        private System.Windows.Forms.Button bt_W;
        private System.Windows.Forms.Button bt_Y;
        private System.Windows.Forms.Button bt_R;
        private System.Windows.Forms.Button bt_T;
        private System.Windows.Forms.Button bt_U;
        private System.Windows.Forms.Button bt_I;
        private System.Windows.Forms.Button bt_O;
        private System.Windows.Forms.Button bt_P;
        private System.Windows.Forms.Button bt_L;
        private System.Windows.Forms.Button bt_K;
        private System.Windows.Forms.Button bt_J;
        private System.Windows.Forms.Button bt_G;
        private System.Windows.Forms.Button bt_F;
        private System.Windows.Forms.Button bt_H;
        private System.Windows.Forms.Button bt_S;
        private System.Windows.Forms.Button bt_D;
        private System.Windows.Forms.Button bt_A;
        private System.Windows.Forms.Button bt_M;
        private System.Windows.Forms.Button bt_B;
        private System.Windows.Forms.Button bt_V;
        private System.Windows.Forms.Button bt_N;
        private System.Windows.Forms.Button bt_X;
        private System.Windows.Forms.Button bt_C;
        private System.Windows.Forms.Button bt_Z;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_kata1;
        private System.Windows.Forms.Label lbl_kata2;
        private System.Windows.Forms.Label lbl_kata3;
        private System.Windows.Forms.Label lbl_kata4;
        private System.Windows.Forms.Label lbl_kata5;
    }
}